//: [Previous](@previous)

//: ## If statments

//: ## Switch

//: ## Ranges & Loops

//: ## Arrays & Dictionaries

//: [Next](@next)
