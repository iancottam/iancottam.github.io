//
//  ViewController.swift
//  FunFacts
//
//  Created by Matthew Spear on 18/04/2016.
//  Copyright © 2016 Matthew Spear. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
  override func viewDidLoad()
  {
    super.viewDidLoad()
  }
}

