# FunFacts
App that displays a random fun fact at the press of a button
